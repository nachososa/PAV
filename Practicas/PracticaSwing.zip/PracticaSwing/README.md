# PrácticaSwing | Interfaces Gráficas en Swing

## NetBeans

1. Abrir NetBeans
2. Menú File → Open Project
3. Buscar la carpeta PracticaSwing
4. En el panel de proyectos, → Run File sobre: EncuestaFrame, ImitadorFrame y ProductosFrame.